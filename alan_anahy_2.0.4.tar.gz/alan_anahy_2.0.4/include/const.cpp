#include <iostream>
#include <cmath>

const float ZERO 0.0;

class ponto {
    private:
        float x, y;
    public:
        ponto(float a, float b) {
            x = a; y = b;
        }
        
        void mostra() {
            cout << "x = " << x << "y = " << y << endl;
        }
        
        float distancia(const ponto hi) const {
            return(float(sqrt((pow(double(hi.x-x),2.0)+pow(double(hi.y-y),2.0)))));
        }
};

int main() {
    ponto ap(3.0,4.0);
    ap.mostra();
    
    const ponto origem(ZERO,ZERO);
    origem.mostra();
    
    cout << "Dist = " << origem.distancia(ap);
} 
